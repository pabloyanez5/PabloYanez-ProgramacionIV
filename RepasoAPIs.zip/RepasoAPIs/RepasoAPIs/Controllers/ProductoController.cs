﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RepasoAPIs.Interfaces;
using RepasoAPIs.Models;
using RepasoAPIs.Repositories;

namespace RepasoAPIs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductoController : ControllerBase
    {
        public IProductoRepository _repoProducto;
        public ProductoController() {
            _repoProducto = new ProductoRepsitory();

        }

        [HttpGet]
        [Route("ObtenerProducto")]
        public IActionResult ObtenerProducto()
        {
            var producto = _repoProducto.ObtenerProducto();
            return NotFound();
        }

        [HttpGet]
        [Route("ObtenerProducto2")]
        public Producto ObtenerProduct2()
        {
            var producto = _repoProducto.ObtenerProducto();
            return producto;
        }

        [HttpPost]
        public IActionResult GuardarProducto([FromBody]Producto producto)
        {
            var guardar = _repoProducto.GuardarProducto(producto);
            return Ok(guardar);
        }

    }
}
