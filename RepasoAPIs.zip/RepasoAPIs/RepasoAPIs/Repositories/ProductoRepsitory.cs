﻿using RepasoAPIs.Interfaces;
using RepasoAPIs.Models;

namespace RepasoAPIs.Repositories
{
    public class ProductoRepsitory : IProductoRepository
    {
        public Producto ObtenerProducto()
        {
            return new Producto
            {
                Id = 1,
                Nombre = "Producto de prueba",
                Precio = 100
            };
        }

        public bool GuardarProducto (Producto producto )
        {
            return true;
        }

        public Producto ObtenerProducto()
        {
            throw new NotImplementedException();
        }

    }

}
