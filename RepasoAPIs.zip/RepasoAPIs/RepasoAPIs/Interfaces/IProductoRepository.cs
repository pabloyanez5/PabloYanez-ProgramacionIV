﻿using RepasoAPIs.Models;

namespace RepasoAPIs.Interfaces
{
    public interface IProductoRepository
    {
        object GuardarProducto(Producto producto);
        Producto ObtenerProducto();
    }
}
